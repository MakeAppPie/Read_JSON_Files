//: Read a JSON file using the Codable protocol 

import UIKit

var myJSON = """
{
    "name":"Huli Pizza Company",
    "cuisine":"Pizza",
    "rating": 5,
    "locations":["Hilo","Honolulu","Waimea","Lihue"],
    "best_Menu_Item":{"item":"Huli Chicken Pizza","price":14.95},
    "menuItems": [
        {"item":"Huli Chicken Pizza","price":14.95},
        {"item":"Coconut Gelato","price":5.95},
        {"item":"Kona Coffee","price":4.95}
    ]
}
""".data(using: .utf8)

struct MenuItem : Codable {
    var item:String
    var price:Double
}

struct Restaurant : Codable {
    private enum CodingKeys : String, CodingKey {
        case name
        case rating
        case locations
        case bestMenuItem = "best_Menu_Item"
        case menuItems
    }
    var name: String
    //var cuisine: String
    var rating: Int
    var locations:[String]
    var bestMenuItem:MenuItem
    var menuItems:[MenuItem]
}

let decoder = JSONDecoder()
let restaurant  = try? decoder.decode(Restaurant.self, from: myJSON!)

if let restaurant = restaurant {
    print(restaurant.name)
    print("Rating: \(restaurant.rating) Slices")
    for location in restaurant.locations{
        print(location)
        
    }
    print("The best Menu Item is \(restaurant.bestMenuItem.item)")
    for item in restaurant.menuItems{
        print ("\(item.item) $\(item.price)")
    }
} else {
    print("Not able to decode JSON")
}


